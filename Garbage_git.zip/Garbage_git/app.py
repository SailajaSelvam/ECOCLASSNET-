from flask import Flask, render_template, request
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array
from PIL import Image
import numpy as np
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
model = load_model('model.h5')

# Configure upload folder
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Label and emission factor setup
waste_labels = {'cardboard': 0, 'glass': 1, 'metal': 2, 'paper': 3, 'plastic': 4, 'trash': 5}
reverse_labels = {v: k for k, v in waste_labels.items()}
emission_factors = {
    'cardboard': 0.9,
    'glass': 0.2,
    'metal': 1.6,
    'paper': 1.0,
    'plastic': 2.9,
    'trash': 1.0
}

def preprocess_image(image):
    image = image.resize((224, 224))  # adjust to your model's input
    image = img_to_array(image)
    image = np.expand_dims(image, axis=0)
    image = image / 255.0
    return image

def calculate_unit_emission(label_index):
    waste_type = reverse_labels.get(label_index)
    emission = emission_factors.get(waste_type, 0.0)
    return waste_type, emission

def recommend_decomposition(waste_type):
    recommendations = {
        'plastic': {
            'method': 'Recycling',
            'alternative_emission': 0.4,
            'default_emission': 2.9
        },
        'paper': {
            'method': 'Recycling',
            'alternative_emission': 0.3,
            'default_emission': 1.0
        },
        'cardboard': {
            'method': 'Recycling',
            'alternative_emission': 0.3,
            'default_emission': 0.9
        },
        'metal': {
            'method': 'Recycling',
            'alternative_emission': 0.15,
            'default_emission': 1.6
        },
        'glass': {
            'method': 'Recycling',
            'alternative_emission': 0.02,
            'default_emission': 0.2
        },
        'trash': {
            'method': 'Landfill',
            'alternative_emission': 1.2,
            'default_emission': 1.0
        }
    }

    if waste_type not in recommendations:
        return {
            "method": "Landfill",
            "avoided_emission": 0.0,
            "note": "Unknown type; fallback to landfill."
        }

    data = recommendations[waste_type]
    avoided = data['default_emission'] - data['alternative_emission']
    return {
        "method": data['method'],
        "avoided_emission": round(avoided, 2),
        "note": f"Switching from incineration to {data['method']} saves approx. {round(avoided, 2)} kg CO₂."
    }

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        file = request.files['file']
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        image = Image.open(filepath).convert("RGB")
        processed = preprocess_image(image)
        prediction = model.predict(processed)
        predicted_class = int(np.argmax(prediction[0]))
        
        waste_type, co2_emission = calculate_unit_emission(predicted_class)
        recommendation = recommend_decomposition(waste_type)

        return render_template(
            'result.html',
            waste_type=waste_type,
            co2_emission=co2_emission,
            prediction_score=float(np.max(prediction[0])),
            suggested_method=recommendation['method'],
            avoided_emission=recommendation['avoided_emission'],
            recommendation_note=recommendation['note'],
            image_path=filename  # Only pass the filename to use in the image URL
        )
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)